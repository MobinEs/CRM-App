export class Service {
    id: string = "";
    name: string = "";
}
