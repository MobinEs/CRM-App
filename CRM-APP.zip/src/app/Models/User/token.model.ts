export class Token {
    token: string = "";
    static TokenName: string = "token";
}