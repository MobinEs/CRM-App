export class Register {
    cellphoneNumber: string = "";
    password: string = "";
}
