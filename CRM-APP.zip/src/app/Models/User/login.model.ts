export class Login {
    cellphoneNumber: string = "00989121234567";
    password: string = "1234512345";
}