export class Authenticated {
    public id: string = "";
    public token: string = "";
    public fullname: string = "";
    public cellphonenumber: string = "";
    public role: number = 0;
    public departmentid: string = "";
}