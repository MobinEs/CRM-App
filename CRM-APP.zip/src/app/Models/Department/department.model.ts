export class Department {
    id: string = "0";
    name: string = "";
}