export class Priority {
    id: string = "";
    name: string = "";
}
