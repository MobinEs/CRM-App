export class TicketType {
    id: string = "";
    name: string = "";
}
