export class ItemDetail {
    value: number = 0;
    id: string = "";
    chartItemId: string = "";
    insertDateTime: Date = new Date();

}