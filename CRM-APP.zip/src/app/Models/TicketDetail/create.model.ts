export class Create {

    public title: string = "";
    public description: string = "";
    public ticketId: string = "";
}