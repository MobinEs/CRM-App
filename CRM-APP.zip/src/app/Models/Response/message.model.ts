export class Message {
    message: string = "";
    code: number = 0;
}
